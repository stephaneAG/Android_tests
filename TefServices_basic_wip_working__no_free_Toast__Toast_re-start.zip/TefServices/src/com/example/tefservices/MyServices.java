package com.example.tefservices;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.Toast;

public class MyServices extends Service {

	@Override
	public IBinder onBind(Intent arg0) { // onBind enables to bind an activity to a service
		// TODO Auto-generated method stub
		return null;
	}
	
	// to explicitly start a service when the user hit the startService button, we use the following method
	@Override
	public int onStartCommand(Intent intent, int flags, int startId){
		
		// this service will run until we stop it
		// ( > actually, this service does not do much except showing a Toast, once started ( & only once (..) ) )
		Toast.makeText(this, " Tef Service Started !", Toast.LENGTH_LONG).show();
		return START_STICKY; // this is what actually keep the service going until explicitly stopped
		
	}
	
	// to explicitly stop the service when the user hit the stopService button
	@Override
	public void onDestroy(){
		super.onDestroy(); // always call the superclass
		Toast.makeText(this, " Tef Service Stopped !", Toast.LENGTH_LONG).show();
	}

}
