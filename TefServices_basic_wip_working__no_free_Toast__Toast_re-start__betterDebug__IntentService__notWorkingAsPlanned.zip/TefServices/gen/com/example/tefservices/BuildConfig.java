/** Automatically generated file. DO NOT MODIFY */
package com.example.tefservices;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}